# coding=utf-8
from __future__ import division
import numpy as np 
from collections import Counter




def parseEvent(line):
    r = {}
    linestrip = line.strip()
    if linestrip == "" or linestrip[0] == "#":
        return None
    r["proc"] = line[0:16].strip()
    l = line[16:].split()
    r["pid"] = int(l[0])
    r["cpu"] = int(l[1][1:-1])
    r["time"] = int(str.join("",l[2][:-1].split(".")))
    r["event"] = l[3].split(":")[1]
    data1 = {}
    data2 = {}
    first = True
    for d in l[4:]:
        if d == "==>":
            first = False
        else:
            e = d.split("=")
            if len(e) == 1:
                if first:
                    data1[ e[0] ] = None
                else:
                    data2[ e[0] ] = None
            elif len(e) == 2:
                if first:
                    data1[ e[0] ] = e[1]
                else:
                    data2[ e[0] ] = e[1]
            else:
              print("ERROR: ",e)
              sys.exit()
    r["data"] = ( data1 , data2 )
    return r


def esta(aguja, pajar):

	for p in pajar : 
		if aguja == p["nombre"]:
			return True
	return False

def esAgregarPrograma(programa):

	if programa["pid"] > 0 : 
		return True
	else : 
		return False

def setearPrograma(unNombreDePrograma, elTiempoDelPrograma):
	a = {
			'nombre' : unNombreDePrograma , 
			'un_cores' : [0 , elTiempoDelPrograma],
			'dos_cores' : [0, 0],
			'tres_cores' : [0, 0],
			'cuatro_cores' : [0, 0]		
		} 
		 
	return a

def match(concurrencia):
	if concurrencia == 1 : 
		return "un_cores"
	if concurrencia == 2 : 
		return "dos_cores"
	if concurrencia == 3 : 
		return "tres_cores"
	if concurrencia == 4 : 
		return "cuatro_cores"

def setearConcurrenciaProcesoViejo(concurrencia_proceso_viejo , proceso_viejo, time , programas, concurrencia_vieja_proceso_viejo):
	i = 0
	for p in programas : 
		if p["nombre"] == proceso_viejo : 
			s = match(concurrencia_proceso_viejo) 
			programas[i][s][0] = programas[i][s][0] + (time - programas[i][s][1])
			programas[i][s][1] = time
			if concurrencia_vieja_proceso_viejo > 0 : 
				s2 = match(concurrencia_vieja_proceso_viejo) 
				programas[i][s2][1] = time
		i = i + 1
	return programas 

def setearConcurrenciaProcesoViejoSinHaberInicializado(concurrencia_proceso_viejo , proceso_viejo, time , programas, concurrencia_vieja_proceso_viejo):
	i = 0
	for p in programas : 
		if p["nombre"] == proceso_viejo : 
			s = match(concurrencia_proceso_viejo) 
			#programas[i][s][0] = programas[i][s][0] + (time - programas[i][s][1])
			programas[i][s][1] = time
			if concurrencia_vieja_proceso_viejo > 0 : 
				s2 = match(concurrencia_vieja_proceso_viejo) 
				programas[i][s2][1] = time
		i = i + 1
	return programas	


def setearConcurrencia(concurrencia, proc, time, programas, concurrencia_vieja):
	i = 0
	#print concurrencia, proc, time, concurrencia_vieja , programas[3]
	if (True):
		for p in programas : 
			if p["nombre"] == proc : 
				s = match(concurrencia)
				if concurrencia_vieja > 0 : 
					s2 = match(concurrencia_vieja)
					programas[i][s2][0] = programas[i][s2][0] + (time - programas[i][s2][1])
					programas[i][s2][1] = time
					programas[i][s][1] = time
				else : 
					programas[i][s][1] = time										
			i = i + 1
	return programas 

def setearConcurrenciaSinHaberIniciado(concurrencia, proc, time, programas, concurrencia_vieja):
	i = 0
	#print concurrencia, proc, time, concurrencia_vieja , programas[3]
	print programas[1]
	if (True):
		for p in programas : 
			if p["nombre"] == proc : 
				s = match(concurrencia)
				if concurrencia_vieja > 0 : 
					s2 = match(concurrencia_vieja)
					programas[i][s2][1] = time
					programas[i][s][1] = time
				else : 
					programas[i][s][1] = time										
			i = i + 1
	return programas 	


def cuantos(r, cpus) : 
	total = 0
	if cpus['cpu3'] == r : 
		total = total + 1
	if cpus['cpu2'] == r : 
		total = total + 1
	if cpus['cpu1'] == r : 
		total = total + 1
	if cpus['cpu0'] == r : 
		total = total + 1

	return total 

def terminarProcesos(time, cpus, programas) : 
	ps = cpus.values()
	ps = Counter(ps)
	for p in ps :  
		i = 0 
		while i < len(programas) : 
			if programas[i]["nombre"] == p : 
				concurrencia = ps[p]
				concurrencia = match(concurrencia)
				programas[i][concurrencia][0] = programas[i][concurrencia][0] + ( time - programas[i][concurrencia][1] )
			i = i + 1




def analizar_concurrencia_por_programa(unArchivo):
	cpus = {'cpu0' : '' , 'cpu1' : '' , 'cpu2' : '' , 'cpu3' : ''}
	programas = [
		{
			'nombre' : 'idle' , 
			'un_cores' : [],
			'dos_cores' : [],
			'tres_cores' : [],
			'cuatro_cores' : []		
		} 
	]
	# Abre archivo en modo lectura
	archivo = open(unArchivo,'r')  
	primero = 0
	actualizado = False
	cpus_inicializados = [0,0,0,0]
	todo_inicializado = False
	f = lambda x : len([ 1 for y in x if y == 1]) == 4
	while True: 
		linea = archivo.readline()  # lee línea
		if not linea: 
			break  # Si no hay más se rompe bucle
		r = parseEvent(linea)
		
		if not actualizado : 
			primero = r["time"]
			actualizado = True

		cpus_inicializados[r["cpu"]] = 1

		if f(cpus_inicializados) : 
			todo_inicializado = True

		cpu = "cpu" + str(r["cpu"]) 
		concurrencia = cuantos(r["proc"], cpus)
		proceso_viejo = cpus[cpu]
		concurrencia_proceso_viejo = cuantos(proceso_viejo, cpus)
		concurrencia_vieja_proceso_viejo = concurrencia_proceso_viejo - 1

		cpus[cpu] = r["proc"]
			
		if  esta(r["proc"] , programas) : 
			concurrencia_nueva = concurrencia + 1
			if todo_inicializado : 
				programas = setearConcurrencia(concurrencia_nueva, r["proc"], r["time"], programas, concurrencia)
			else : 
				programas = setearConcurrenciaSinHaberIniciado(concurrencia_nueva, r["proc"], r["time"], programas, concurrencia)
		else : 	
			concurrencia_nueva = 1
			s = setearPrograma(r["proc"], r["time"])
			programas.append(s)
			
			# ahora tmb debemos setear los valores del proceso anterior q estaba corriendo en ese cpuu
		if not proceso_viejo == "":
			if todo_inicializado : 
				programas = setearConcurrenciaProcesoViejo(concurrencia_proceso_viejo , proceso_viejo, r["time"] , programas, concurrencia_vieja_proceso_viejo)
			else : 
				programas = setearConcurrenciaProcesoViejoSinHaberInicializado(concurrencia_proceso_viejo , proceso_viejo, r["time"] , programas, concurrencia_vieja_proceso_viejo)
	## ahora tengo q calcular los q me qedaron q estan esperando terminar 
	#print cpus
	tiempo = r["time"] - primero 
	if todo_inicializado : 
		terminarProcesos(r["time"], cpus, programas) 

	resultadoFinal = []
	for p in programas : 
		nombre = p["nombre"]
		if not nombre == 'idle':
			uno = p["un_cores"][0] / tiempo
			dos = p["dos_cores"][0] / tiempo
			tres = p["tres_cores"][0] / tiempo
			cuatro = p["cuatro_cores"][0] / tiempo
			uno = p["un_cores"][0] 
			dos = p["dos_cores"][0] 
			tres = p["tres_cores"][0] 
			cuatro = p["cuatro_cores"][0]
			total_corriendo = uno + dos + tres + cuatro
			"""uno = p["un_cores"][0] 
			dos = p["dos_cores"][0] 
			tres = p["tres_cores"][0] 
			cuatro = p["cuatro_cores"][0] """

			resultado = [nombre, uno, dos ,tres, cuatro, total_corriendo] 
			resultadoFinal.append(resultado)


	archivo.close  # Cierra archivo
	return resultadoFinal

print analizar_concurrencia_por_programa('script.data')