from pylab import *


def graficar(linea):
	datos = linea.split(",")
	figure()
	ax = axes([0.05, 0, 0.9, 0.9])# donde esta la figura ancho alto etc..
	labels = '1 core ', '2 cores', '3 cores', '4 cores'#nomre de los datos
	datos[1] = round(float(datos[1]),2)
	datos[2] = round(float(datos[2]),2) 
	datos[3] = round(float(datos[3]),2) 
	datos[4] = round(float(datos[4]),2)

	i = 1 
	cuales = []


	fracs = [datos[1], datos[2], datos[3], datos[4]]#datos a graficar
	index = fracs.index(max(fracs))
	explode=[0, 0, 0, 0]#exposicion de uno de los datos segun donde se encuentra 
	explode[index] = 0.1
	pie(fracs, explode=explode,labels=labels, autopct='%10.5f%%', shadow=True)
	legend()
	title('Concurrencia en el programa:' + datos[0], bbox={'facecolor':'0.8', 'pad':5})

	savefig(datos[0]+".png")
	#show()#mostrar grafico


file = open("mayores_concurrencia.csv", "r")
lines = file.readlines()[1:]
for f in lines : 
	print f 
	graficar(f)


