from pylab import *


def graficar():
	ax = axes([0.06, 0, 0.9, 0.9])# donde esta la figura ancho alto etc..
	labels = '1 core ', '2 cores' , '3 cores' , '4 cores' #nomre de los datos

	i = 1 
	cuales = []


	fracs = [71.31081686082378,16.882942534796978,9.043139338682883,2.763101232656542]#datos a graficar
	index = fracs.index(max(fracs))
	explode=[0, 0, 0, 0]#exposicion de uno de los datos segun donde se encuentra 
	explode[index] = 0.1
	pie(fracs, explode=explode,labels=labels, autopct='%10.5f%%', shadow=True)
	legend()
	title('Concurrencia en swappers. 16 "%" de tiempo corriendo sobre el total', bbox={'facecolor':'0.8', 'pad':5})

	savefig("torta_swapper.png")
	#show()#mostrar grafico


graficar()


