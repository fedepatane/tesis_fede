import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np 
from sklearn.cluster import KMeans


data_frame = pd.read_csv("data.csv")
#sns.pairplot(data_frame)
#plt.show()
#print data_frame



k_means = KMeans(n_clusters = 8)
k_means.fit(data_frame)


inercias = []
for i in range(1, 40):
	k_means = KMeans(n_clusters = i)
	k_means.fit(data_frame)
	inercias.append(k_means.inertia_)
plt.plot(inercias)
plt.grid(True)
plt.show()
plt.savefig("elbow_method.png")







k_means = KMeans(n_clusters = 4)
k_means.fit(data_frame)
for i in k_means.cluster_centers_ : 
	for j in i : 
		print '%.10f' % j
	print "-----------------------------"		
