# coding=utf-8
import sys
import numpy as np
import pylab as P
import glob
import subprocess
import os 
import tarfile
from dataProcess_Concurrency import *

from programas_con_cachitos_por_core_io_estirado import concurrencia_por_cachito

import MySQLdb
 
DB_HOST = 'localhost' 
DB_USER = 'root' 
DB_PASS = '1234' 
DB_NAME = 'data' 
 
def run_query(query=''): 
	datos = [DB_HOST, DB_USER, DB_PASS, DB_NAME] 
 
	conn = MySQLdb.connect(*datos) # Conectar a la base de datos 
	cursor = conn.cursor()         # Crear un cursor 
	cursor.execute(query)          # Ejecutar una consulta 
 
	if query.upper().startswith('SELECT'): 
		data = cursor.fetchall()   # Traer los resultados de un select 
	else: 
		conn.commit()              # Hacer efectiva la escritura de datos 
		data = cursor.lastrowid 
 
	cursor.close()                 # Cerrar el cursor 
	conn.close()                   # Cerrar la conexión 
 

	return data


cores = 4
directorio = "../SERVIDOR/DATOS"
file_to_store_the_data = "analisis_io"
pointer_to_file = open(file_to_store_the_data, "a")

i = 0 
sos_data = (lambda x : x.split(".")[3] == "data")
los_positivos = (lambda x : len(x["firefox"]) > 0 or len(x["chrome"]) > 0)
for labo in os.listdir(directorio) : 
	laboDir = directorio + "/" + labo
	for maquina in  os.listdir(laboDir): 
		maquinaDir = laboDir + "/" + maquina
		for materia in os.listdir(maquinaDir) : 
			materiaDir = maquinaDir + "/" + materia
			for fecha in os.listdir(materiaDir) :
				fechaDir =  materiaDir + "/" + fecha
				l = [ fechaDir + "/" + x for x in os.listdir(fechaDir)]
				lista_con_archivos_data = filter(sos_data, l)				
				l = filter(los_positivos, map(concurrencia_por_cachito, lista_con_archivos_data))
				print i 
				i = i  + 1
				for programas in l : 
					a , b , c = processConcurrency(programas["archivo"], 4)
					if not a == None : 
						if a[0][3] <= 95 : 
							cpu_utilizado = a[1][3] + a[2][3] + a[3][3] + a[4][3]
							#print cpu_utilizado
							programas.pop('archivo', None)
							for k , v in programas.items() :
								cantidad_cores = 0
								for tiempos in v :
									cantidad_cores = cantidad_cores + 1
									for d in tiempos : 
										#if d <= 10000 : 
										if True : 
											pointer_to_file.write(k + "\t" + str(cantidad_cores) + "\t" + str(d) + "\t" + str(cpu_utilizado) + "\n" )									
											#run_query("INSERT INTO programas_cachitos_por_core (id_muestra, programa, dato, cantidad_cores) values ('%s', '%s', '%s', '%s')" % (muestra, k , d, cantidad_cores))

pointer_to_file.close()