# coding=utf-8
import numpy as np


def parseEvent(line):
    r = {}
    linestrip = line.strip()
    if linestrip == "" or linestrip[0] == "#":
        return None
    r["proc"] = line[0:16].strip()
    l = line[16:].split()
    r["pid"] = int(l[0])
    r["cpu"] = int(l[1][1:-1])
    r["time"] = int(str.join("",l[2][:-1].split(".")))
    r["event"] = l[3].split(":")[1]
    data1 = {}
    data2 = {}
    first = True
    for d in l[4:]:
        if d == "==>":
            first = False
        else:
            e = d.split("=")
            if len(e) == 1:
                if first:
                    data1[ e[0] ] = None
                else:
                    data2[ e[0] ] = None
            elif len(e) == 2:
                if first:
                    data1[ e[0] ] = e[1]
                else:
                    data2[ e[0] ] = e[1]
            else:
              print("ERROR: ",e)
              sys.exit()
    r["data"] = ( data1 , data2 )
    return r


def match(unCore):

	if unCore == 0 : 
		return "core_0"
	if unCore == 1 : 
		return "core_1"
	if unCore == 2 : 
		return "core_2"
	if unCore == 3 : 
		return "core_3"

def concurrencia_por_cachito(unArchivo):
	print unArchivo
	programas = {}
	programas["java"] = {"historico" : [] , "core_0" : -1 , "core_1" : -1 , "core_2" : -1 , "core_3" : -1}
	programas["chrome"] = {"historico" : [] , "core_0" : -1 , "core_1" : -1 , "core_2" : -1 , "core_3" : -1}
	programas["firefox"] = {"historico" : [] , "core_0" : -1 , "core_1" : -1 , "core_2" : -1 , "core_3" : -1}
	programasCorriendoPorCore = { "0" : "" , "1" : "" ,"2" : "" ,"3" : "" }
	
	archivo = open(unArchivo,'r')  

	while True : 
		linea = archivo.readline()  # lee línea
		if not linea: 
			break  # Si no hay más se rompe bucle
		r = parseEvent(linea)
		#i have to see if the incoming line , is from an swith event 
		if r["event"] == 'sched_switch': 		
			programaCorriendo = programasCorriendoPorCore[str(r["cpu"])]
			programasCorriendoPorCore[str(r["cpu"])] = r["proc"]

			if programas.has_key(programaCorriendo):
				tiempoActualDeEseProgramaEnEseCore = programas[programaCorriendo][match(r["cpu"])]
				if tiempoActualDeEseProgramaEnEseCore == -1 : 
					programas[programaCorriendo][match(r["cpu"])] = r["time"]
				else : 
					tiempo = r["time"] - tiempoActualDeEseProgramaEnEseCore
					programas[programaCorriendo]["historico"].append(tiempo)
					programas[programaCorriendo][match(r["cpu"])] = -1
			
			if programas.has_key(r["proc"]) : 
				programas[r["proc"]][match(r["cpu"])] = r["time"]

	programas2 = {}
	programas2["chrome"] = programas["chrome"]["historico"]
	programas2["firefox"] = programas["firefox"]["historico"]
	programas2["java"] = programas["java"]["historico"]
	
	return programas2

#print concurrencia_por_cachito("data.data")
