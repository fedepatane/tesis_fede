# coding=utf-8
import sys
import numpy as np
import pylab as P
import glob
import subprocess
import os 
import tarfile

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
from dataProcess_Events import *
from dataProcess_Users import *
from dataProcess_Concurrency import *
from dataProcess_Application import *
from concurrencia_por_programa import *
from analizador_tiempo_por_tarea import * 

from dateutil.parser import parse

from programas_con_cachitos import concurrencia_por_cachito

import MySQLdb
 
DB_HOST = 'localhost' 
DB_USER = 'root' 
DB_PASS = '1234' 
DB_NAME = 'data' 
 
def run_query(query=''): 
	datos = [DB_HOST, DB_USER, DB_PASS, DB_NAME] 
 
	conn = MySQLdb.connect(*datos) # Conectar a la base de datos 
	cursor = conn.cursor()         # Crear un cursor 
	cursor.execute(query)          # Ejecutar una consulta 
 
	if query.upper().startswith('SELECT'): 
		data = cursor.fetchall()   # Traer los resultados de un select 
	else: 
		conn.commit()              # Hacer efectiva la escritura de datos 
		data = cursor.lastrowid 
 
	cursor.close()                 # Cerrar el cursor 
	conn.close()                   # Cerrar la conexión 
 

	return data


cores = 4
directorio = "SERVIDOR/DATOS"
#folder = "data_perfs"

sos_data = (lambda x : x.split(".")[1] == "data")
los_positivos = (lambda x : len(x["java"]) > 0 or len(x["firefox"]) > 0 or len(x["chrome"]) > 0)
for labo in os.listdir(directorio) : 
	laboDir = directorio + "/" + labo
	for maquina in  os.listdir(laboDir): 
		maquinaDir = laboDir + "/" + maquina
		for materia in os.listdir(maquinaDir) : 
			materiaDir = maquinaDir + "/" + materia
			for fecha in os.listdir(materiaDir) :
				fechaDir =  materiaDir + "/" + fecha
				l = [ fechaDir + "/" + x for x in os.listdir(fechaDir)]
				lista_con_archivos_data = filter(sos_data, l)
				l = filter(los_positivos, map(concurrencia_por_cachito, lista_con_archivos_data))
				for programas in l : 
					muestra = run_query("select max(id_muestra) from programas_por_cachitos")[0][0]
					print muestra
					if muestra == None : 
						muestra = 1
					else : 
						muestra = muestra + 1
					for k , v in programas.items() :
						for tiempos in v : 	
							run_query("INSERT INTO programas_por_cachitos (id_muestra, programa, dato) values ('%s', '%s', '%s')" % (muestra, k , tiempos)) 
