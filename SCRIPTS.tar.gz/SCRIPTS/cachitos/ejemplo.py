import pandas as pd 

file = "analisis_io_bkp"
list_with_header = ["program" , "quantity_cores", "data", "procesor_usage"]


df = pd.read_table(file, engine='python', sep='\t', header=None, names=list_with_header)


df = df[df.procesor_usage <= 110]
df.to_csv("analisis_io" , sep="\t" , index=False, header=False)