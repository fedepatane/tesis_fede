from __future__ import division
import pandas as pd


def f(programa, core, parameter):

	data_frame = pd.read_csv(programa + "_" + core + ".txt", names=["index", "time", "porcentage"], usecols=["time"], sep='\t')
	data_frame_io = pd.read_csv(programa + "_io_" + core + ".txt", names=["index", "time_io", "porcentage"], usecols=["time_io"], sep='\t')

	list_pds = [data_frame, data_frame_io]
	result = pd.concat(list_pds, axis = 1)

	total_veces_io = result.loc[(result['time'] < result['time_io'])].count()["time"]

	total_veces_io_grande = result.loc[(result['time'] + result['time'] * parameter / 100 < result['time_io'])].count()["time"]

	totales_cachitos = result.count()["time"]
	if total_veces_io == 0: 
		a = 0
		b = 0
	else :
		if totales_cachitos == 0 : 
			a = 0
			b = 0
		else : 
			a = total_veces_io / totales_cachitos * 100
			b = total_veces_io_grande / total_veces_io * 100
	variable = {"programa" : programa,
				"cantidad_cores" : core , 
				"porcentaje_entra_io" : a, 
				"porcentaje_io_no_gratis" : b}
	resultado = pd.Series(variable)			
	with open('datos', 'a') as f:
		resultado.to_csv(f, header=False)
		f.write("\n")

f("chrome", "1", 10)
f("chrome", "2", 10)
f("chrome", "3", 10)
f("chrome", "4", 10)