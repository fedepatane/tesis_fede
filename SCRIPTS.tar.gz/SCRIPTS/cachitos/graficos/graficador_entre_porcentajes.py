from matplotlib.pylab import hist, show
import matplotlib.pyplot as plt

def histograma(programa):
	total = []
	f = lambda x : int(x.split("\n")[0].split("\t")[1])
	f2 = lambda x : x <= 1000	

	file = open("<50/"+ programa + "_1.txt", "r")
	v = file.readlines()
	file.close()
	v1 = filter(f2, map(f, v))

	file = open(">70/"+programa + "_1.txt", "r")
	v = file.readlines()
	file.close()
	v2 = filter(f2, map(f, v))

	file = open("50-70/"+programa + "_1.txt", "r")
	v = file.readlines()
	file.close()
	v3 = filter(f2, map(f, v))

	binwidth = 20

	hist(v1,bins=range(min(v1), max(v1) + binwidth, binwidth) , label= "<50")
	hist(v3,bins=range(min(v3), max(v3) + binwidth, binwidth) , label= "50-70")
	hist(v2,bins=range(min(v2), max(v2) + binwidth, binwidth) , label= ">70")

	plt.title("Distibucion de tiempos corriendo con 1 core, segun cantidad de uso del cpu. " + programa)
	plt.legend(loc='upper right')
	plt.xlabel("Tiempo corriendo")
	plt.ylabel("Cantidad muestras")


	plt.savefig(programa + '_histograma_por_uso_1.png')
	plt.show()



	file = open("<50/"+ programa + "_2.txt", "r")
	v = file.readlines()
	file.close()
	v1 = filter(f2, map(f, v))

	file = open(">70/"+programa + "_2.txt", "r")
	v = file.readlines()
	file.close()
	v2 = filter(f2, map(f, v))

	file = open("50-70/"+programa + "_2.txt", "r")
	v = file.readlines()
	file.close()
	v3 = filter(f2, map(f, v))

	binwidth = 20

	hist(v1,bins=range(min(v1), max(v1) + binwidth, binwidth) , label= "<50")
	hist(v2,bins=range(min(v2), max(v2) + binwidth, binwidth) , label= ">70")
	hist(v3,bins=range(min(v3), max(v3) + binwidth, binwidth) , label= "50-70")
	plt.title("Distibucion de tiempos corriendo con 2 cores, segun cantidad de uso del cpu. " + programa)
	plt.legend(loc='upper right')
	plt.xlabel("Tiempo corriendo")
	plt.ylabel("Cantidad muestras")
	plt.savefig(programa + '_histograma_por_uso_2.png')
	plt.show()





	file = open("<50/"+ programa + "_3.txt", "r")
	v = file.readlines()
	file.close()
	v1 = filter(f2, map(f, v))

	file = open(">70/"+programa + "_3.txt", "r")
	v = file.readlines()
	file.close()
	v2 = filter(f2, map(f, v))

	file = open("50-70/"+programa + "_3.txt", "r")
	v = file.readlines()
	file.close()
	v3 = filter(f2, map(f, v))


	binwidth = 20

	hist(v1,bins=range(min(v1), max(v1) + binwidth, binwidth) , label= "<50")
	hist(v2,bins=range(min(v2), max(v2) + binwidth, binwidth) , label= ">70")
	hist(v3,bins=range(min(v3), max(v3) + binwidth, binwidth) , label= "50-70")
	plt.title("Distibucion de tiempos corriendo con 3 cores, segun cantidad de uso del cpu. " + programa)
	plt.legend(loc='upper right')
	plt.xlabel("Tiempo corriendo")
	plt.ylabel("Cantidad muestras")
	plt.savefig(programa + '_histograma_por_uso_3.png')

	plt.show()


histograma('chrome')
