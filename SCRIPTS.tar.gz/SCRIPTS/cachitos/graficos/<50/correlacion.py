from matplotlib.pylab import hist, show
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

def histograma(programa, core):

	total = []
	f = lambda x : int(x.split("\n")[0].split("\t")[1])
	#f2 = lambda x : int(x) <= 500
	f2 = lambda x : int(x) <= 800

	file = open(programa + "_io_"+core+".txt", "r")
	v = file.readlines()
	file.close()
	v1 = map(f, v)
	#v1 = filter(f2, v1)

	file = open(programa + "_"+core+".txt", "r")
	v = file.readlines()
	file.close()
	v2 = map(f, v)
	#v2 = filter(f2, v2)

	#v2 = v2[0:len(v1)]

	plt.scatter(v2, v1)


	plt.title("Distibucion de tiempos corriendo. Menor 50 %" + programa)
	plt.legend(loc='upper right')
	plt.xlabel("NO IO")
	plt.ylabel("IO")


	plt.savefig(programa + '_histograma_'+core+'core_io_vs_noio.png')
	plt.show()

	#plt.figure()

histograma('chrome', '1')
histograma('chrome', '2')
histograma('chrome', '3')
histograma('chrome', '4')



"""
import pandas as pd 

file = "chrome_io_1.txt"
file2 = "chrome_1.txt"
list_with_header1 = ["index" , "data"]
list_with_header2 = list_with_header1


table = pd.read_table(file, engine='python', sep='\t', header=None, names=list_with_header1)
table2 = pd.read_table(file2, engine='python', sep='\t', header=None, names=list_with_header2)

"""

# hace distribucion normal 
#sns.distplot(table["data"])
#sns.distplot(table2["data"])

#compara dos columnas con sus distribuciones de un frame 
#sns.jointplot(x = , y = , data = , kind = '')

# pair plot uno vs todos 


"""
sns.jointplot(x = table["data"], y = table2["data"] , kind = 'reg')
plt.savefig("regresion.png")
plt.show()
"""
