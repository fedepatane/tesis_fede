from matplotlib.pylab import hist, show
import matplotlib.pyplot as plt

def histograma(programa):

	total = []
	f = lambda x : int(x.split("\n")[0].split("\t")[1])
	f2 = lambda x : x <= 1000	

	file = open(programa + "_1.txt", "r")
	v = file.readlines()
	file.close()
	v1 = filter(f2, map(f, v))
	total = total + v1

	#plt.savefig('chrome_histograma.png')
	#plt.show()
	#plt.figure()


	file = open(programa + "_2.txt", "r")
	v = file.readlines()
	file.close()
	v2 = filter(f2, map(f, v))
	total = total + v2

	#plt.savefig('chrome_histograma.png')
	#plt.show()

	#plt.figure()

	file = open(programa + "_3.txt", "r")
	v = file.readlines()
	file.close()
	v3 = filter(f2, map(f, v))
	total = total + v3

	binwidth = 20


	hist(total,bins=range(min(total), max(total) + binwidth, binwidth), label= "total_cores")
	hist(v1,bins=range(min(v1), max(v1) + binwidth, binwidth) , label= "1_core")
	hist(v2,bins=range(min(v2), max(v2) + binwidth, binwidth) , label= "2_cores")
	hist(v3,bins=range(min(v3), max(v3) + binwidth, binwidth) , label= "3_cores")
	plt.title("Distibucion de tiempos corriendo. Entre 50 y 70 %" + programa)
	plt.legend(loc='upper right')
	plt.xlabel("Tiempo corriendo")
	plt.ylabel("Cantidad muestras")


	plt.savefig(programa + '_histograma_por_core.png')
	plt.show()

	#plt.figure()

histograma('chrome')