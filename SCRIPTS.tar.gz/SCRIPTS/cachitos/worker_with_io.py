import pandas as pd 

file = "analisis_io"
list_with_header = ["program" , "quantity_cores", "data", "procesor_usage"]

table = pd.read_table(file, engine='python', sep='\t', header=None, names=list_with_header)


#now i have in table the data frame with all the data like a mysql table

#the idea will be to execute queries on that data to store it on a file
#to after that could execute the graphics on it 

## an example of a multiple select 
## #chrome_3 = table.loc[(table['program'] == 'chrome') & (table['quantity_cores'] == 3) , ["data"]]


chrome = table.loc[(table['program'] == 'chrome')]

chrome_1 = chrome.loc[(chrome['quantity_cores'] == 1) , ["data", "procesor_usage"]]
chrome_2 = chrome.loc[(chrome['quantity_cores'] == 2) , ["data", "procesor_usage"]]
chrome_3 = chrome.loc[(chrome['quantity_cores'] == 3) , ["data", "procesor_usage"]]
chrome_4 = chrome.loc[(chrome['quantity_cores'] == 4) , ["data", "procesor_usage"]]



# now we have to throw it to a file , and after that , from an script
# take it up and parse it to generate the graphics


chrome_1.to_csv('chrome_io_1.txt' , sep = "\t")
chrome_2.to_csv('chrome_io_2.txt' , sep = "\t")
chrome_3.to_csv('chrome_io_3.txt' , sep = "\t")
chrome_4.to_csv('chrome_io_4.txt' , sep = "\t")
