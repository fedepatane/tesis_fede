import pandas as pd 


def f(programa, archivo):

	file = archivo
	list_with_header = ["program" , "quantity_cores", "data", "procesor_usage"]

	table = pd.read_table(file, engine='python', sep='\t', header=None, names=list_with_header)
	if archivo == "analisis_io" : 
		aux = "_io"
	else : 
		aux = ""

	#now i have in table the data frame with all the data like a mysql table

	#the idea will be to execute queries on that data to store it on a file
	#to after that could execute the graphics on it 

	## an example of a multiple select 
	## #chrome_3 = table.loc[(table['program'] == 'chrome') & (table['quantity_cores'] == 3) , ["data"]]


	chrome = table.loc[(table['program'] == programa)]

	chrome_1 = chrome.loc[(chrome['quantity_cores'] == 1) , ["data", "procesor_usage"]]
	chrome_2 = chrome.loc[(chrome['quantity_cores'] == 2) , ["data", "procesor_usage"]]
	chrome_3 = chrome.loc[(chrome['quantity_cores'] == 3) , ["data", "procesor_usage"]]
	chrome_4 = chrome.loc[(chrome['quantity_cores'] == 4) , ["data", "procesor_usage"]]


	chrome_1.to_csv('graficos/general/'+programa+aux+'_1.txt' , sep = "\t")
	chrome_2.to_csv('graficos/general/'+programa+aux+'_2.txt' , sep = "\t")
	chrome_3.to_csv('graficos/general/'+programa+aux+'_3.txt' , sep = "\t")
	chrome_4.to_csv('graficos/general/'+programa+aux+'_4.txt' , sep = "\t")

	chrome_1_menor = chrome.loc[(chrome['quantity_cores'] == 1) & (chrome["procesor_usage"] <= 50.0) , ["data", "procesor_usage"]]
	chrome_2_menor = chrome.loc[(chrome['quantity_cores'] == 2) & (chrome["procesor_usage"] <= 50.0), ["data", "procesor_usage"]]
	chrome_3_menor = chrome.loc[(chrome['quantity_cores'] == 3) & (chrome["procesor_usage"] <= 50.0), ["data", "procesor_usage"]]
	chrome_4_menor = chrome.loc[(chrome['quantity_cores'] == 4) & (chrome["procesor_usage"] <= 50.0), ["data", "procesor_usage"]]

	chrome_1_menor.to_csv('graficos/<50/'+programa+aux+'_1.txt' , sep = "\t")
	chrome_2_menor.to_csv('graficos/<50/'+programa+aux+'_2.txt' , sep = "\t")
	chrome_3_menor.to_csv('graficos/<50/'+programa+aux+'_3.txt' , sep = "\t")
	chrome_4_menor.to_csv('graficos/<50/'+programa+aux+'_4.txt' , sep = "\t")


	chrome_1_entre = chrome.loc[(chrome['quantity_cores'] == 1) & (chrome["procesor_usage"] >= 50.0) & (chrome["procesor_usage"] <= 70.0) , ["data", "procesor_usage"]]
	chrome_2_entre = chrome.loc[(chrome['quantity_cores'] == 2) & (chrome["procesor_usage"] >= 50.0) & (chrome["procesor_usage"] <= 70.0), ["data", "procesor_usage"]]
	chrome_3_entre = chrome.loc[(chrome['quantity_cores'] == 3) & (chrome["procesor_usage"] >= 50.0) & (chrome["procesor_usage"] <= 70.0), ["data", "procesor_usage"]]
	chrome_4_entre = chrome.loc[(chrome['quantity_cores'] == 4) & (chrome["procesor_usage"] >= 50.0) & (chrome["procesor_usage"] <= 70.0), ["data", "procesor_usage"]]

	chrome_1_entre.to_csv('graficos/50-70/'+programa+aux+'_1.txt' , sep = "\t")
	chrome_2_entre.to_csv('graficos/50-70/'+programa+aux+'_2.txt' , sep = "\t")
	chrome_3_entre.to_csv('graficos/50-70/'+programa+aux+'_3.txt' , sep = "\t")
	chrome_4_entre.to_csv('graficos/50-70/'+programa+aux+'_4.txt' , sep = "\t")

	chrome_1_mayor = chrome.loc[(chrome['quantity_cores'] == 1) & (chrome["procesor_usage"] >= 70.0), ["data", "procesor_usage"]]
	chrome_2_mayor = chrome.loc[(chrome['quantity_cores'] == 2) & (chrome["procesor_usage"] >= 70.0), ["data", "procesor_usage"]]
	chrome_3_mayor = chrome.loc[(chrome['quantity_cores'] == 3) & (chrome["procesor_usage"] >= 70.0), ["data", "procesor_usage"]]
	chrome_4_mayor = chrome.loc[(chrome['quantity_cores'] == 4) & (chrome["procesor_usage"] >= 70.0), ["data", "procesor_usage"]]

	chrome_1_mayor.to_csv('graficos/>70/'+programa+aux+'_1.txt' , sep = "\t")
	chrome_2_mayor.to_csv('graficos/>70/'+programa+aux+'_2.txt' , sep = "\t")
	chrome_3_mayor.to_csv('graficos/>70/'+programa+aux+'_3.txt' , sep = "\t")
	chrome_4_mayor.to_csv('graficos/>70/'+programa+aux+'_4.txt' , sep = "\t")

f("sublime_text", "analisis")
f("sublime_text", "analisis_io")
