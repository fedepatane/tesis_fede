from matplotlib.pylab import hist, show
import matplotlib.pyplot as plt

def histograma():

	f = lambda x : int(float(x.split("\n")[0]))

	file = open("0.csv", "r")
	v = file.readlines()[1:]
	file.close()
	v0 = map(f, v)


	file = open("1.csv", "r")
	v = file.readlines()[1:]
	file.close()
	v1 = map(f, v)

	file = open("2.csv", "r")
	v = file.readlines()[1:]
	file.close()
	v2 = map(f, v)

	file = open("3.csv", "r")
	v = file.readlines()[1:]
	file.close()
	v3 = map(f, v)

	file = open("4.csv", "r")
	v = file.readlines()[1:]
	file.close()
	v4 = map(f, v)



	binwidth = 3


	hist(v0,bins=range(min(v0), max(v0) + binwidth, binwidth) , label= "idle")
	hist(v1,bins=range(min(v1), max(v1) + binwidth, binwidth) , label= "1 core")
	hist(v2,bins=range(min(v2), max(v2) + binwidth, binwidth) , label= "2 cores")
	hist(v3,bins=range(min(v3), max(v3) + binwidth, binwidth) , label= "3 cores")
	hist(v4,bins=range(min(v4), max(v4) + binwidth, binwidth) , label= "4 cores")
	plt.title("Distibucion de paralelismo.")
	plt.legend(loc='upper right')
	plt.xlabel("Porcentaje corriendo")
	plt.ylabel("Cantidad muestras")


	plt.savefig("histogramas_paralelismo.png")
	plt.show()

	#plt.figure()

histograma()