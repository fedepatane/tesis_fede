from pylab import *
import datetime as dt  

def f(tipo):
	file = open("promedio.csv", "r")
	programas = []
	tiempos = []
	lines = file.readlines()[1]
	"""for f in file : 
		dato = f.split(",")
		programa = dato[0]
		tc = float(dato[1])
		programas.append(programa)
		tiempos.append(tc)"""
	lines = map(float , lines.split("\n")[0].split(","))
	tiempos = [lines[0] , lines[1] , lines[2], lines[3], lines[4]] 
	programas = ["0 cores" , "1 core" , "2 cores" , "3 cores" , "4 cores"]
	cantidad = len(tiempos)
	# generamos las fechas de los ultimos cinco dias
	plt.axes((0.1, 0.3, 0.8, 0.6))  
	# Definimos la posicion de los ejes
	plt.bar(np.arange(cantidad), tiempos)  
	# Dibujamos el grafico de barras
	plt.ylim(0,100)  
	# Limitamos los valores del eje y al range definido [0, 100]
	plt.title('Promedio de cores corriendo con ' + tipo)  
	# Colocamos el titulo
	plt.xticks(np.arange(cantidad), programas, rotation = 45)  
	# Colocamos las etiquetas del eje x, en este caso, las fechas
	plt.savefig("promedio_procesadores.png")


f("50 - 70 %")