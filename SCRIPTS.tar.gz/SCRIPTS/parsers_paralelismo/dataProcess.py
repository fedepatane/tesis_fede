import sys
import numpy as np
import pylab as P
import glob
import subprocess

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
from dataProcess_Events import *
from dataProcess_Users import *
from dataProcess_Concurrency import *
from dataProcess_Application import *
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #


#P.hist(sets[0], 50, normed=1, histtype='stepfilled')
#P.figure()
#P.hist(sets[1], 50, normed=1, histtype='stepfilled')
#P.figure()
#P.hist(sets[2], 50, normed=1, histtype='stepfilled')
#P.figure()
#P.hist(sets[3], 50, normed=1, histtype='stepfilled')

#P.show()
#datafile = "perf.data.parsed"
#dat = process(datafile,cores)
#print glob.glob("/home/david/GIT/processor-usage/DATA/data/*/perf.data.parsed")

cores = 4
#folder = "/home/david/GIT/processor-usage/DATA/data/"
folder = 'home/federico/GIT/processor-usage/pruebas'
##RUNprocessConcurrency(folder,cores)

#RUNprocessUsers(folder,cores)


##files = ['/home/david/GIT/processor-usage/DATA/data/ws8.labo7/1433370972/perf.data.parsed']
##files = ['/home/david/GIT/processor-usage/DATA/data/ws8.labo7/1433377632/perf.data.parsed']
##files = ['/home/david/GIT/processor-usage/DATA/data/ws19.labo7/1433371512/perf.data.parsed']

#files = ['/home/david/GIT/processor-usage/DATA/data/ws8.labo7/1433370972/perf.data.parsed',
         #'/home/david/GIT/processor-usage/DATA/data/ws8.labo7/1433377632/perf.data.parsed',
         #'/home/david/GIT/processor-usage/DATA/data/ws19.labo7/1433371512/perf.data.parsed']

files = ['script']


##files = ['/home/david/GIT/processor-usage/LOCAL/manual.perf.data.parsed']

#for f in files:
    ##result,sets,data = processConcurrency(f,cores)
    #result,tasks,data = processApplication(f,cores)
    #usrPre,usrPost,valid = processUsers(f)
    
    #if valid:
        #print(usrPre)
    #else:
        #print("non valid")
    #print(result)
    ##d = map(lambda x: str(x[0]) + "_" + x[1], data)
    ##a = [ (len([ y for y in d if y == x ]),x) for x in set(d) ]
    
    
    
    
#RUNprocessApplication(folder,cores)
    
    
RUNprocessConcurrency("results/",cores)
    
    
    
    
    
    
    


