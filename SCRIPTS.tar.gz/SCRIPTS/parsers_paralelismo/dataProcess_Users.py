import sys
import os
import numpy as np
import pylab as P
import glob
import subprocess

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# === processUsers ===
# Esta funcion encuentra los archivos de who_pre y who_post y los
# parsea retornando una estructura de la forma:
#             { <user>: [<terminal>, ... ], ... }
# tanto para pre como para post. Ademas informa si ambos archivos
# son iguales.
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
def processUsers(datafile):

    if datafile[-1] != '/':
        datafile = '/' + '/'.join(datafile.split('/')[1:-1]) + '/'
    f_pre = open(datafile + 'who_pre', 'r')
    f_post = open(datafile + 'who_post', 'r')
    
    usrPre = {}
    for line in f_pre:
        l = line.split()
        if len(l)== 5:
            if not usrPre.has_key(l[0]):
                usrPre[l[0]] = [l[1]]
            else:
                usrPre[l[0]] = usrPre[l[0]] + [l[1]]
        else:
            print(l)
    usrPost = {}
    for line in f_post:
        l = line.split()
        if len(l)== 5:
            if not usrPost.has_key(l[0]):
                usrPost[l[0]] = [l[1]]
            else:
                usrPost[l[0]] = usrPost[l[0]] + [l[1]]
        else:
            print(l)
    
    usrPre = { i:sorted(x) for i,x in usrPre.iteritems() }
    usrPost = { i:sorted(x) for i,x in usrPost.iteritems() }
    
    return usrPre, usrPost, usrPre == usrPost

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# === RUNprocessUsers ===
# Ejecuta la funcion processUsers para las archivos dentro de
# folder. Genera un resumen de todos los datos no nulos y otro
# con los usuarios validos que corrian en cada maquina sin
# cambios.
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
def RUNprocessUsers(folder):
    findCMD = 'find ' + folder + ' -name "*who_pre"'
    out = subprocess.Popen(findCMD,shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (stdout, stderr) = out.communicate()

    files = stdout.split()
    
    fileDataUsers = open("usersData.txt", 'w')
    fileSummUsers = open("usersSummary.txt", 'w')

    for f in files:

        a = f.split("/")
        name = '/'.join(a[7:9])
        
        usrPre=None
        usrPost=None
        valid=None
        
        try:
            usrPre, usrPost, valid = processUsers(f)
        except:
            print("ERROR: " + f )
        
        if usrPre != None and len(usrPre.keys())!=0:
            fileDataUsers.write(str(a))
            fileDataUsers.write(" || ")           
            fileDataUsers.write(str(usrPre))
            fileDataUsers.write(" || ")
            fileDataUsers.write(str(usrPost))
            fileDataUsers.write(" || ")
            fileDataUsers.write(str(valid))
            fileDataUsers.write("\n")
            
            if valid:
                fileSummUsers.write(os.path.dirname(f))
                fileSummUsers.write(" || ")
                fileSummUsers.write(str(usrPre.keys()))
                fileSummUsers.write("\n")
            
        else:
            print("ERROR: " + f )

    fileDataUsers.close()
    fileSummUsers.close()

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #