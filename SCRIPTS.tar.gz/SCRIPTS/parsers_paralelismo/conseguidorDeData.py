import sys
import numpy as np
import pylab as P
import glob
import subprocess
import os , shutil
import tarfile

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

directorio = "../SERVIDOR/DATOS"

labos = os.listdir(directorio)
for labo in labos : 
	laboDir = directorio + "/" + labo
	if os.path.isdir(laboDir) : 
		maquinas = os.listdir(laboDir)
		for maquina in maquinas : 
			maquinaDir = directorio + "/" + labo + "/" + maquina
			if os.path.isdir(maquinaDir) : 
				materias = os.listdir(maquinaDir)
				for materia in materias : 
					materiaDir = directorio + "/" + labo + "/" + maquina + "/" + materia
					if os.path.isdir(materiaDir) :
						fechas = os.listdir(materiaDir)
						for fecha in fechas : 
							fechaDir = materiaDir + "/" + fecha
							if os.path.isdir(fechaDir):
								files = os.listdir(fechaDir)
								for f in files : 
									aux = f.split(".") 
									if aux[1] == "data" : 
										print labo , maquina , f
										filesDir = fechaDir + "/" + f
										aux = filesDir.split(".")
										filesDirReport = aux[0] + ".report" 
										os.system("mv " + filesDir + " perf.data")
										os.system("chown root perf.data")
										os.system("sudo perf script > script.data")
										os.system("sudo perf report > script.report")
										os.system("rm perf.data")
										os.system("mv script.data " + filesDir)
										os.system("mv script.report " + filesDirReport)

