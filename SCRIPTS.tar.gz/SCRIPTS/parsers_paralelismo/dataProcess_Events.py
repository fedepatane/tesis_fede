import sys
import numpy as np
import pylab as P
import glob
import subprocess

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# === parseEvent ===
# Pasea los eventos de perf con el siguiente formato:
# {'cpu': <n>, 'event': <name>, 'pid': <num>, 'proc': <procName>,
#  'data': ( {<key>: <val>, ... }, {<key>: <val>, ... } ),
#  'time': <timeStamp> }
# Ejemplo:
#  { 'cpu': 2,
#    'data': ({'prev_comm': 'rcu_sched', 'prev_pid': '7', 'prev_prio': '120', 'prev_state': 'S'},
#             {'next_comm': 'swapper/2', 'next_pid': '0', 'next_prio': '120'}),
#    'event': 'sched_switch',
#    'pid': 7,
#    'proc': 'rcu_sched',
#    'time': 8860862305 }
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
def parseEvent(line):
    r = {}
    linestrip = line.strip()
    if linestrip == "" or linestrip[0] == "#":
        return None
    r["proc"] = line[0:16].strip()
    l = line[16:].split()
    r["pid"] = int(l[0])
    r["cpu"] = int(l[1][1:-1])
    r["time"] = int(str.join("",l[2][:-1].split(".")))
    r["event"] = l[3].split(":")[1]
    data1 = {}
    data2 = {}
    first = True
    for d in l[4:]:
        if d == "==>":
            first = False
        else:
            e = d.split("=")
            if len(e) == 1:
                if first:
                    data1[ e[0] ] = None
                else:
                    data2[ e[0] ] = None
            elif len(e) == 2:
                if first:
                    data1[ e[0] ] = e[1]
                else:
                    data2[ e[0] ] = e[1]
            else:
              print("ERROR: ",e)
              sys.exit()
    r["data"] = ( data1 , data2 )
    return r

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# === processEvents ===
# Lee un archivo y parsea todos los eventos de este
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
def processEvents(datafile):
    f = open(datafile, 'r')
    events = []
    for line in f:
        e = parseEvent(line)
        if e != None and e['event'] == 'sched_switch':
            events.append(e)
    return events
