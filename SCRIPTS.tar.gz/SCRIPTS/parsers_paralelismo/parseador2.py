# coding=utf-8
import sys
import numpy as np
import pylab as P
import glob
import subprocess
import os 
import tarfile

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
from dataProcess_Events import *
from dataProcess_Users import *
from dataProcess_Concurrency import *
from dataProcess_Application import *
from concurrencia_por_programa import *

from dateutil.parser import parse

import MySQLdb




from programas_con_cachitos_por_core import concurrencia_por_cachito as parseador_cachitos_por_core
from programas_con_cachitos_por_core_io import concurrencia_por_cachito as parseador_cachitos_por_core_io


 
DB_HOST = 'localhost' 
DB_USER = 'root' 
DB_PASS = '1234' 
DB_NAME = 'data' 
 
def run_query(query=''): 
	datos = [DB_HOST, DB_USER, DB_PASS, DB_NAME] 
 
	conn = MySQLdb.connect(*datos) # Conectar a la base de datos 
	cursor = conn.cursor()         # Crear un cursor 
	cursor.execute(query)          # Ejecutar una consulta 
 
	if query.upper().startswith('SELECT'): 
		data = cursor.fetchall()   # Traer los resultados de un select 
	else: 
		conn.commit()              # Hacer efectiva la escritura de datos 
		data = cursor.lastrowid 
 
	cursor.close()                 # Cerrar el cursor 
	conn.close()                   # Cerrar la conexión 
 

	return data

cores = 4
directorio = "../SERVIDOR/DATOS"
cachitos = open("../cachitos/analisis" , "a")
cachitos_io = open("../cachitos/analisis_io" , "a")

concu = open("../concurrencia_por_programa/concurrencia_por_programa" , "a")

def analizarMemoria(mem_archivo) : 
	datos = mem_archivo.readline().rstrip('\n').split(" ")
	total , usada , libre = datos[0] , datos[1] , datos[2]
	return total , usada , libre

def escribirArchivo(unaCarpetaConDatos, unaMateria, fechaPosta, labo, maquina) : 
	# agarrar a los archivos .data , pasarle el script q te de la concurrencia y 
	# dsp pasamos esos datos a un archivo con el nombre de esa materia 
	fechaPosta = fechaPosta.split("-")
	fechaPosta = fechaPosta[2] + "-" + fechaPosta[1] + "-" + fechaPosta[0]
	
	#archivo = open("analisis/" + unaMateria , "a")
	if os.path.isdir(unaCarpetaConDatos) : 
		files = os.listdir(unaCarpetaConDatos)
		for f in files : 
			test = f.split(".")
			hora = test[0].split("_")[1]
			fechaMasHora = fechaPosta + " " + hora
			fechaPosta = parse(fechaMasHora).strftime("%Y-%m-%d %H:%M:%S")

			if test[1] == "data" : 	
				usuario = unaCarpetaConDatos + "/" + test[0] + ".usuarios"
				idle = unaCarpetaConDatos + "/" + test[0] + ".idle"
				memoria = unaCarpetaConDatos + "/" + test[0] + ".memoria"
				procesos = unaCarpetaConDatos + "/" + test[0] + ".procesos"
				report = unaCarpetaConDatos + "/" + test[0] + ".report"
				if os.path.exists(usuario) and os.path.exists(idle) and os.path.exists(memoria) and os.path.exists(procesos) :
					usuarioArchivo = open(usuario, "r")
					idleArchivo = open(idle, "r")
					memoriaArchivo = open(memoria, "r")
					procesosArchivo = open(procesos, "r")
					cantidadProcesos = len(procesosArchivo.readlines()) - 1
					cantidadUsuarios = len(usuarioArchivo.readlines())
					
					tiempoIdle = int(0)
					memoriaTotal , memoriaLibre, memoriaUsada = analizarMemoria(memoriaArchivo)
					usuarioArchivo.close()
					idleArchivo.close()
					memoriaArchivo.close()
					procesosArchivo.close()
					#print unaCarpetaConDatos + "/" + f
					a , b , c = processConcurrency(unaCarpetaConDatos + "/" + f, 4)
					llegaronA_correrTodos , concurrencia_archivo = analizar_concurrencia_por_programa(unaCarpetaConDatos + "/" + f)
					if llegaronA_correrTodos : 
						#tiempo_por_tarea = analizar_tiempo_por_tarea(report)
						if not a == None : 
							print "hola"
							z_core = a[0][3]
							o_core = a[1][3]
							t_core = a[2][3]
							th_core = a[3][3]
							f_core = a[4][3]
							tot = o_core + t_core + th_core + f_core
							if z_core <= 95 : 
								pass
								"""
								insert = "INSERT INTO data (0_core , 1_core , 2_core , 3_core , 4_core , labo , maquina , mem_total , mem_usada, cant_usuarios , fecha, cant_procesos) VALUES ('%s' , '%s' , '%s' , '%s' , '%s' ,  '%s' , '%s' , '%s' , '%s' , '%s' , '%s' , '%s')" % (z_core , o_core , t_core , th_core , f_core , labo , maquina , memoriaTotal , memoriaUsada, cantidadUsuarios, fechaPosta , cantidadProcesos)
								id_muestra = run_query(insert)
								for programa in concurrencia_archivo : 
									nombre = programa[0]
									uno = programa[1]
									dos = programa[2]
									tres = programa[3]
									cuatro = programa[4]
									total = programa[5]
									#if not nombre == 'swapper' : 
									if True : 	
										insert = "INSERT INTO concurrencia_por_programa (id_muestra, programa, one_core, two_cores, three_cores, four_cores, total_corriendo, total_corriendo_muestra) VALUES ('%s' , '%s' , '%s' , '%s' , '%s' ,  '%s',  '%s',  '%s') " % (0, nombre , uno, dos , tres , cuatro, total , tot)
										run_query(insert)
								
								tiempos_sin_io = parseador_cachitos_por_core(unaCarpetaConDatos + "/" + f)
								tiempos_io = parseador_cachitos_por_core_io(unaCarpetaConDatos + "/" + f)
								for k , v in tiempos_io.items() :
									cantidad_cores = 0
									for tiempos in v :
										cantidad_cores = cantidad_cores + 1
										for d in tiempos : 
											cachitos_io.write(k + "\t" + str(cantidad_cores) + "\t" + str(d) + "\t" + str(tot) +"\n" )									

								for k , v in tiempos_sin_io.items() :
									cantidad_cores = 0
									for tiempos in v :
										cantidad_cores = cantidad_cores + 1
										for d in tiempos : 
											cachitos.write(k + "\t" + str(cantidad_cores) + "\t" + str(d) + "\t" + str(tot) +"\n" )									
								"""
							else : 
								# if its an idle file , i will delete it , to 
								# not make the other scripts parse that data 
								# and we put it into the database , the metadata
								print "inserto idle"
								insert = "INSERT INTO data_idle (labo, maquina, fecha, z_cores , o_core, t_core , th_core , f_core) VALUES ('%s','%s','%s','%s','%s','%s','%s','%s') " % (labo, maquina, fechaPosta, z_core , o_core, t_core , th_core , f_core)
								run_query(insert)

								#os.remove(unaCarpetaConDatos + "/" + f)
	return 1

def evaluar(unaDireccionDeMateria, labo , maquina) : 
	labo = int(labo.split("_")[1])
	maquina = int(maquina.split("_")[1])
	fechas = os.listdir(unaDireccionDeMateria)
	unaMateria = unaDireccionDeMateria.split("/")[-1:][0]
	for fecha in fechas : 
		fechaPosta = fecha
		fecha = unaDireccionDeMateria + "/" + fecha
		if os.path.isdir(fecha) : 
			escribirArchivo(fecha, unaMateria, fechaPosta, labo, maquina)
	return 1


labos = os.listdir(directorio)
for labo in labos : 
	laboDir = directorio + "/" + labo
	if os.path.isdir(laboDir) : 
		maquinas = os.listdir(laboDir)
		for maquina in maquinas : 
			maquinaDir = directorio + "/" + labo + "/" + maquina
			if os.path.isdir(maquinaDir) : 
				materias = os.listdir(maquinaDir)
				for materia in materias : 
					materiaDir = directorio + "/" + labo + "/" + maquina + "/" + materia
					if os.path.isdir(materiaDir) :
						evaluar(materiaDir, labo , maquina)




"""for file in files : 
	print file + " : "
	archivo = folder + "/" + file
	a , b, c = processConcurrency(archivo, cores)
	print a"""

#a , b, c, = processApplication("muchos_pi", cores)

#print a