# coding=utf-8
import numpy as np


def parseEvent(line):
    r = {}
    linestrip = line.strip()
    if linestrip == "" or linestrip[0] == "#":
        return None
    r["proc"] = line[0:16].strip()
    l = line[16:].split()
    r["pid"] = int(l[0])
    r["cpu"] = int(l[1][1:-1])
    r["time"] = int(str.join("",l[2][:-1].split(".")))
    r["event"] = l[3].split(":")[1]
    data1 = {}
    data2 = {}
    first = True
    for d in l[4:]:
        if d == "==>":
            first = False
        else:
            e = d.split("=")
            if len(e) == 1:
                if first:
                    data1[ e[0] ] = None
                else:
                    data2[ e[0] ] = None
            elif len(e) == 2:
                if first:
                    data1[ e[0] ] = e[1]
                else:
                    data2[ e[0] ] = e[1]
            else:
              print("ERROR: ",e)
              sys.exit()
    r["data"] = ( data1 , data2 )
    return r


def match(unCore):

	if unCore == 0 : 
		return "core_0"
	if unCore == 1 : 
		return "core_1"
	if unCore == 2 : 
		return "core_2"
	if unCore == 3 : 
		return "core_3"

def terminar_procesos(unaLista, unTiempo):
	for k in unaLista : 
		concurrencias = unaLista[k]["concurrencias"]
		for c in concurrencias : 
			if len(c) > 0 : 
				#esto es para hacer un truco , por q la primera es una lista vacia q 
				#es para no tener q poner el -1 en las concurrencias
				if c["tiempo"] > 0 : 
					#significa q se qedo corriendo algo -> lo tenemos q meter en terminado
					tiempo_corrido = unTiempo - c["tiempo"]
					if tiempo_corrido > 0 : 
						c["historico"].append(tiempo_corrido)
					c["tiempo"] = 0
	return unaLista 




def get(unDiccionario): 
	result = {}
	for k in unDiccionario : 
		concus = unDiccionario[k]["concurrencias"]
		aux = [concus[1]["historico"], concus[2]["historico"], concus[3]["historico"], concus[4]["historico"]]
		result[k] = aux
	return result

def concurrencia_por_cachito(unArchivo):
	print unArchivo
	programas = {}
	programas["chrome"] = {"concurrencias" : [[] , {"tiempo" : 0 , "historico" : []} , {"tiempo" : 0 , "historico" : []} , {"tiempo" : 0 , "historico" : []} , {"tiempo" : 0 , "historico" : []}]}
	programas["firefox"] = {"concurrencias" : [[] , {"tiempo" : 0 , "historico" : []} , {"tiempo" : 0 , "historico" : []} , {"tiempo" : 0 , "historico" : []} , {"tiempo" : 0 , "historico" : []}]}
	programas["geany"] = {"concurrencias" : [[] , {"tiempo" : 0 , "historico" : []} , {"tiempo" : 0 , "historico" : []} , {"tiempo" : 0 , "historico" : []} , {"tiempo" : 0 , "historico" : []}]}
	programas["sublime_text"] = {"concurrencias" : [[] , {"tiempo" : 0 , "historico" : []} , {"tiempo" : 0 , "historico" : []} , {"tiempo" : 0 , "historico" : []} , {"tiempo" : 0 , "historico" : []}]}

	programasCorriendoPorCore = { "0" : "" , "1" : "" ,"2" : "" ,"3" : "" }
	
	archivo = open(unArchivo,'r')  

	
	cuantos = lambda k , lista : len([1 for x in lista if lista[x] == k])

	while True : 
		linea = archivo.readline()  # lee línea
		if not linea: 
			break  # Si no hay más se rompe bucle
		r = parseEvent(linea)

		if r["event"] == 'sched_switch':
			#trabajar con el programa reemplazado 
			programaReemplazado = programasCorriendoPorCore[str(r["cpu"])]
			if programas.has_key(programaReemplazado):
				concurrencia_actual_programa_reemplazado = cuantos(programaReemplazado, programasCorriendoPorCore)
				#acabar esa concurrencia para ese programa 
				tiempo_de_desalojo = r["time"]
				tiempo_corrido = tiempo_de_desalojo - programas[programaReemplazado]["concurrencias"][concurrencia_actual_programa_reemplazado]["tiempo"]
				#le tengo q decir al programa reemplazado q empiece a contar con 1 concurrencia menos ahora
				if concurrencia_actual_programa_reemplazado > 1 : 
					concurrencia_vieja_programa_reemplazado = concurrencia_actual_programa_reemplazado - 1
					programas[programaReemplazado]["concurrencias"][concurrencia_vieja_programa_reemplazado]["tiempo"] = r["time"]


				#seteo las variables para esa concurrencia en ese programa
				programas[programaReemplazado]["concurrencias"][concurrencia_actual_programa_reemplazado]["tiempo"] = 0
				programas[programaReemplazado]["concurrencias"][concurrencia_actual_programa_reemplazado]["historico"].append(tiempo_corrido)


			#trabajar con el programa que esta entrando 
			programa_entrante = r["proc"]
			tiempo_actual = r["time"]
			programasCorriendoPorCore[str(r["cpu"])] = programa_entrante
			concurrencia_programa_entrante = cuantos(programa_entrante, programasCorriendoPorCore)
			if programas.has_key(programa_entrante) : 
				#le tengo q decir a la vieja concurrencia del programa q ya termino de contar esa concurrencia 
				if concurrencia_programa_entrante > 1 : 
					concurrencia_vieja_programa_actual = concurrencia_programa_entrante - 1
					tiempo_corrido = tiempo_actual - programas[programa_entrante]["concurrencias"][concurrencia_vieja_programa_actual]["tiempo"]
					programas[programa_entrante]["concurrencias"][concurrencia_vieja_programa_actual]["tiempo"] = 0
					programas[programa_entrante]["concurrencias"][concurrencia_vieja_programa_actual]["historico"].append(tiempo_corrido)

				#le digo a la nueva concurrencia del nuevo programa , q arranque a contar 
				programas[programa_entrante]["concurrencias"][concurrencia_programa_entrante]["tiempo"] = tiempo_actual		
	
	#programas = terminar_procesos(programas, tiempo_actual)
	programas = get(programas)
	return programas


#a = concurrencia_por_cachito("data.data")
#print len(a["chrome"][0]) , len(a["chrome"][1]) , len(a["chrome"][2]), len(a["chrome"][3])