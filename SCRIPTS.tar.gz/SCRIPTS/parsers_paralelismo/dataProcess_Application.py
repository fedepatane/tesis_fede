import sys
import numpy as np
import pylab as P
import glob
import subprocess
from dataProcess_Events import *

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# === processApplication ===
# Lee una trazas y genera tres resultados
# result: Diccionario de vectores, las claves son los nombres de
#         los procesos y los valores los tiempos de cada core
# tasks: Vector ordenado de tuplas de nombre de procesos y tiempo
#        total de cada uno
# data: Vector de eventos, cada tupla contiene, timeStamp, numero
#       de core, tiempo de cuenta y nombre de proceso
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
def processApplication(datafile,cores):
    f = open(datafile, 'r')

    data = []
    lasts = [None] * cores
    allok = [None] * cores
    
    for line in f:
        e = parseEvent(line)
        
        if e != None and e['event'] == 'sched_switch':
            
            if lasts[e['cpu']] != None:
              
                allok[e['cpu']] = True  
                timeDiff = e['time']-lasts[e['cpu']]['time']
                
                if allok.count(None) == 0:
                    data.append( (e['time'],e['cpu'],timeDiff,e['proc']) )
                    
            lasts[e['cpu']] = e
            
    tasks = set(map(lambda x: x[3], data))
        
    result = { x:([0] * cores) for x in tasks }

    for d in data:
        result[d[3]][d[1]] += d[2]
        
    tasks = map(lambda x: (sum(result[x]),x) ,tasks)
    
    tasks.sort()

    return result,tasks,data
  
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# === RUNprocessApplication ===
# Lee las trazas crudas y genera tres archivos por traza
# result: Resultados de las corridas, cada tarea en cada core 
#       cada linea con el formato:
#       <procName> [<timeCountCore0>, ..., <timeCountCoreN>]
# tasks: Resumen de tiempo por cada tarea
#       cada linea con el formato:
#       (<totalTimeCount>, <procName>)
# data: La data cruda de cada aplicacion y su tiempo por cores
#       cada linea con el formato:
#       (<timeStamp>, <core>, <timeCount>, <procName>)
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
def RUNprocessApplication(folder,cores):
    findCMD = 'find ' + folder + ' -name "*parsed"'
    out = subprocess.Popen(findCMD,shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (stdout, stderr) = out.communicate()

    files = stdout.split()

    for f in files:

        a = f.split("/")
        name = '_'.join(a[7:9])
        
        result=None
        tasks=None
        data=None
        
        try:
            result,tasks,data = processApplication(f,cores)
        except:
            print("ERROR: " + f )
        
        if result != None:
          
            #summ = " ".join(map(lambda x: "{:10.3f}".format(x[3]),result)) + "{:25}".format(result[0][2]) + "{:25}".format(sum(map(lambda x: x[4],result)))
            
            fileResults = open("results/"+name+"_result.txt", 'w')
            fileTasks = open("results/"+name+"_tasks.txt", 'w')
            fileData = open("results/"+name+"_data.txt", 'w')

            for r in result.items():
                fileResults.write(str(r[0]))
                fileResults.write(" ")
                fileResults.write(str(r[1]))
                fileResults.write("\n")
                
            for r in tasks:
                fileTasks.write(str(r))
                fileTasks.write("\n")
                
            for r in data:
                fileData.write(str(r))
                fileData.write("\n")
            
            fileResults.close()
            fileTasks.close()
            fileData.close()
            
        else:
            print("ERROR: " + f )

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# === RUNprocessApplicationSummary ===
# Lee los resultados generados por RUNprocessApplication y arma
# un agregado de todos los datos, generando un archivo de datos
# con el siguiente formato:
# <procName> <avg> <max> <min> <count>
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
def RUNprocessApplicationSummary(folder,cores):
    lsCMD = 'ls -1 ' + folder
    out = subprocess.Popen(lsCMD,shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (stdout, stderr) = out.communicate()

    files = stdout.split()
    filesName = list( set( map(lambda x : "_".join((x.split("_"))[0:2]) , files ) ) )
   
    data = {}
    for name in filesName:
        
        with open(folder+"/"+name+"_tasks.txt", 'r') as fileTasks:
            for line in fileTasks:
                a = eval(line)
                if data.has_key(a[1]):
                  data[a[1]] = data[a[1]] + [a[0]]
                else:
                  data[a[1]] = [a[0]]
       
    results = {}
    for i in data:
       results[i] = (float(sum(data[i]))/float(len(data[i])),min(data[i]),max(data[i]),len(data[i]))
    
    r = results.items()
    
    r.sort(key=lambda x: (x[1])[0] )
    
    fileSummary = open("summary.txt", 'w')
    for i in r:    
        fileSummary.write( i[0].ljust(20) + "\t" )
        fileSummary.write( ('%.2f'%i[1][0]).ljust(15) + "\t" )
        fileSummary.write( str(i[1][1]).ljust(15) + "\t" )
        fileSummary.write( str(i[1][2]).ljust(15) + "\t" )
        fileSummary.write( str(i[1][3]).ljust(15) + "\n" )
    fileSummary.close()

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #