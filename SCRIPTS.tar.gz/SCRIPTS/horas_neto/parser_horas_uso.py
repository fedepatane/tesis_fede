from datetime import datetime


def parsearFecha(toma):

	toma = toma.split(" ")
	fecha = toma[0]
	hora = toma[1]
	fecha = fecha.split("-")
	hora = hora.split(":")
	fecha = map(int, fecha)
	hora = map(int, hora)
	return fecha[0], fecha[1], fecha[2], hora[0], hora[1], hora[2]

def match(b): 
	if b == 1 : 
		return "acumulado_idles_actuales"
	else : 
		return "acumulado_noidles_actuales"



def f(datos):

	estructura_aux = {}
	for labo, maquinas in datos.iteritems() : 
		estructura_aux[labo] = {}
		for maquina in maquinas : 
			estructura_aux[labo][maquina] = {"ultima_actual": 0, 
											"primera_actual": 0,
											"acumulado_idles_actuales" : 0,
											"acumulado_noidles_actuales" : 0,
											"acumulado_minutos_idles" : []}



	for labo, maquinas in datos.iteritems() : 
		for maquina, tomas in maquinas.iteritems() : 
			for toma in tomas : 
				ano , mes , dia , hora , minutos , segundos = parsearFecha(toma[0])
				momento = datetime(ano, mes , dia , hora , minutos)
				tipo = match(toma[1])
				if estructura_aux[labo][maquina]["ultima_actual"] == 0 : 
					#significa que tdv no arranque 
					estructura_aux[labo][maquina]["primera_actual"] = momento
					estructura_aux[labo][maquina]["ultima_actual"] = momento
					estructura_aux[labo][maquina][tipo] = 1
				else : 
					diferencia =  momento - estructura_aux[labo][maquina]["ultima_actual"]
					diferencia_segundos = diferencia.total_seconds()
					if diferencia_segundos <= 5 * 60 : 
						#significa que estoy en rango entonces acumulo 
						estructura_aux[labo][maquina]["ultima_actual"] = momento
						estructura_aux[labo][maquina][tipo] = estructura_aux[labo][maquina][tipo] + 1
					else : 
						#significa que tengo que dejar de contar 
						#sumo a lo que ya tenia para esta 
						idles = estructura_aux[labo][maquina]["acumulado_idles_actuales"]
						noidles = estructura_aux[labo][maquina]["acumulado_noidles_actuales"]
						tiempo = (idles + noidles) * 5
						l = [tiempo, idles, noidles]
						estructura_aux[labo][maquina]["acumulado_minutos_idles"].append(l)
						estructura_aux[labo][maquina]["ultima_actual"] = momento
						estructura_aux[labo][maquina]["primera_actual"] = momento
						estructura_aux[labo][maquina]["acumulado_idles_actuales"] = 0
						estructura_aux[labo][maquina]["acumulado_noidles_actuales"] = 0
						estructura_aux[labo][maquina][tipo] = 1
			#aca vamos a cerrar al actual antes de pasar a la proxima
			#maquina del proximo labo
			idles = estructura_aux[labo][maquina]["acumulado_idles_actuales"]
			noidles = estructura_aux[labo][maquina]["acumulado_noidles_actuales"]
			tiempo = (idles + noidles) * 5
			l = [tiempo, idles, noidles]
			estructura_aux[labo][maquina]["acumulado_minutos_idles"].append(l)
			estructura_aux[labo][maquina]["ultima_actual"] = momento
			estructura_aux[labo][maquina]["primera_actual"] = momento
			estructura_aux[labo][maquina]["acumulado_idles_actuales"] = 0
			estructura_aux[labo][maquina]["acumulado_noidles_actuales"] = 0
			estructura_aux[labo][maquina][tipo] = 1





	return estructura_aux


	
#print f({
#		"labo1" : {"maquina1" : [['2017-06-29 16:10:09', 1], ['2017-06-29 16:15:09', 1],['2017-06-29 16:20:09', 1], ['2017-06-29 16:30:09', 0], ['2017-06-29 16:40:09', 0]]},
#		"labo2" : {"maquina1" : [['2017-06-29 16:10:09', 1], ['2017-06-29 16:15:09', 1],['2017-06-29 16:20:09', 1], ['2017-06-29 16:30:09', 0], ['2017-06-29 16:40:09', 0]]}
 #		})


