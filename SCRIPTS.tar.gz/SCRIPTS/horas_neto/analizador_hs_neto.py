#ATENCION , ACORDATE CUANDO LO HAGAS CON DATOS VERDADEROS DE Q DEBEN SER A PARTIR
#DEL 2 DE SEPTIEMBRE QUE ES CUANDO EMPEZAMOS A CONTAR TMB LOS NO IDLE 

#select labo, maquina, fecha, 0 as idle from data order by labo, maquina , fecha asc;
#select labo, maquina, fecha, 1 as idle from data_idle order by labo, maquina , fecha asc;

import pandas as pd
from parser_horas_uso import *

df_noIdle = pd.read_csv("no_idle.csv") 
df_idle = pd.read_csv("idle.csv")


frames = [df_noIdle, df_idle]
result = pd.concat(frames)


result = result.sort_values(['labo','maquina', 'fecha'], ascending=[True,True,True])
labos = result.labo.unique()
aux = {}
for labo in labos : 
	maquinas = result.loc[(result["labo"] == labo), ["maquina"]].maquina.unique()
	aux[labo] = {}
	for maquina in maquinas : 
		aux[labo][maquina] = {}
		fechas = result.loc[(result["labo"] == labo) & (result["maquina"] == maquina)]
		l = []
		for index , row in fechas.iterrows():
			l.append([row["fecha"], row["idle"]])
		aux[labo][maquina] = l
print f(aux)