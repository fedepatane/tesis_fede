from pylab import *


def graficar():
	ax = axes([0.06, 0, 0.9, 0.9])# donde esta la figura ancho alto etc..
	labels = '1 core ', '2 cores' #nomre de los datos

	i = 1 
	cuales = []


	fracs = [99.63047795727964, 0.36887385784295484]#datos a graficar
	index = fracs.index(max(fracs))
	explode=[0, 0]#exposicion de uno de los datos segun donde se encuentra 
	explode[index] = 0.1
	pie(fracs, explode=explode,labels=labels, autopct='%10.5f%%', shadow=True)
	legend()
	title('Concurrencia en tareas del SO', bbox={'facecolor':'0.8', 'pad':5})

	savefig("torta_kworker.png")
	#show()#mostrar grafico


graficar()


