from matplotlib.pylab import hist, show
import matplotlib.pyplot as plt

def histograma():

	f = lambda x : x.split("\n")[0]

	f1 = lambda x : int(float(x.split(",")[0]))
	f2 = lambda x : int(float(x.split(",")[1]))
	f3 = lambda x : int(float(x.split(",")[2]))
	f4 = lambda x : int(float(x.split(",")[3]))

	file = open("concurrencia_sobre_tiempo_corrido.csv", "r")
	v = file.readlines() 
	file.close()
	v = map(f, v)

	v0 = map(f1, v)
	v1 = map(f2, v)
	v2 = map(f3, v)
	v3 = map(f4, v)

	binwidth = 10


	hist(v0,bins=range(min(v0), max(v0) + binwidth, binwidth) , label= "1 core")
	hist(v1,bins=range(min(v1), max(v1) + binwidth, binwidth) , label= "2 cores")
#	hist(v2,bins=range(min(v2), max(v2) + binwidth, binwidth) , label= "3 cores")
#	hist(v3,bins=range(min(v3), max(v3) + binwidth, binwidth) , label= "4 cores")

	plt.title("Distibucion de concurrencia. Tareas del SO")
	plt.legend(loc='upper right')
	plt.xlabel("Porcentaje corriendo")
	plt.ylabel("Cantidad muestras")


	plt.savefig("histogramas_kworkers.png")
	plt.show()

	#plt.figure()

def histograma2(unCore):
	f = lambda x : x.split("\n")[0]

	f1 = lambda x : int(float(x.split(",")[0]))
	f2 = lambda x : int(float(x.split(",")[1]))
	f3 = lambda x : int(float(x.split(",")[2]))
	f4 = lambda x : int(float(x.split(",")[3]))

	file = open("concurrencia_sobre_tiempo_corrido.csv", "r")
	v = file.readlines() 
	file.close()
	v = map(f, v)

	v0 = map(f1, v)
	v1 = map(f2, v)
	v2 = map(f3, v)
	v3 = map(f4, v)

	binwidth = 5

	v = [v0,v1,v2,v3]
	v = v[unCore - 1]

	hist(v,bins=range(min(v), max(v) + binwidth, binwidth) , label= str(unCore) + " core")
#	hist(v1,bins=range(min(v1), max(v1) + binwidth, binwidth) , label= "2 cores")
#	hist(v2,bins=range(min(v2), max(v2) + binwidth, binwidth) , label= "3 cores")
#	hist(v3,bins=range(min(v3), max(v3) + binwidth, binwidth) , label= "4 cores")

	plt.title("Concurrencia en tareas del SO.")
	plt.legend(loc='upper right')
	plt.xlabel("Porcentaje de tiempo corriendo")
	plt.ylabel("Cantidad muestras")


	plt.savefig("histogramas_kworkers_"+str(unCore)+".png")
	plt.show()


histograma()

histograma2(1)
histograma2(2)