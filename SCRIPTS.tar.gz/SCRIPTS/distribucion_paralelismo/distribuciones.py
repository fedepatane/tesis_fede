from matplotlib.pylab import hist, show
import matplotlib.pyplot as plt

def histograma(nombre):

	f = lambda x : x.split("\n")[0]
	f2 = lambda x : map(int, map(float , x.split(",")))
	t0 = lambda x : x[0]
	t1 = lambda x : x[1]
	t2 = lambda x : x[2]
	t3 = lambda x : x[3]
	t4 = lambda x : x[4]


	file = open(nombre + ".csv", "r")
	v = file.readlines()
	file.close()
	v = map(f,v)

	v = map(f, v)
	v = map(f2, v)
	v0 = map(t0, v)
	v1 = map(t1, v)
	v2 = map(t2, v)
	v3 = map(t3, v)
	v4 = map(t4, v)
 

	binwidth = 3


	hist(v0,bins=range(min(v0), max(v0) + binwidth, binwidth) , label= "idle")
	hist(v1,bins=range(min(v1), max(v1) + binwidth, binwidth) , label= "1 core")
	hist(v2,bins=range(min(v2), max(v2) + binwidth, binwidth) , label= "2 cores")
	hist(v3,bins=range(min(v3), max(v3) + binwidth, binwidth) , label= "3 cores")
	hist(v4,bins=range(min(v4), max(v4) + binwidth, binwidth) , label= "4 cores")
	plt.title("Distibucion de paralelismo muestras " + nombre + "%")
	plt.legend(loc='upper right')
	plt.xlabel("Porcentaje corriendo por core")
	plt.ylabel("Cantidad muestras")


	plt.savefig(nombre + ".png")

	plt.show()

	#plt.figure()

histograma('menor_50')
histograma('50-70')
histograma('70-100')
