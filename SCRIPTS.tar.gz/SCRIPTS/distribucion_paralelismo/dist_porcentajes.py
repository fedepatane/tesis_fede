import pandas as pd 
import seaborn as sns
import matplotlib.pyplot as plt

file = "sumas.csv"
list_with_header1 = ["suma"]

table = pd.read_table(file, engine='python', sep='\t', header=None, names=list_with_header1)


sns.distplot(table["suma"] , bins = 10)
plt.show()