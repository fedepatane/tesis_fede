#!/usr/bin/env python

servidorConfiguracion = "SERVIDOR/CONFIGURACION/" #esto es remoto  
servidorDatos = "SERVIDOR/DATOS/"   # esto es remoto 
archivo_config_general = "SERVIDOR/CONFIGURACION/config_general"
archivo_config_version = "SERVIDOR/CONFIGURACION/version_servidor"
archivo_update_recolector = "SERVIDOR/CONFIGURACION/recolectorDatos.py"
archivo_update_funciones = "SERVIDOR/CONFIGURACION/funciones.py"



username_ssh = "federico"
ip_ssh = "juan23.exp.dc.uba.ar"
password_ssh = "ledesma15"

RUTA_EJECUTABLE = "./idle" # esto es local de cada maquina
RUTA_VERSION_ACTUAL_DE_LA_MAQUINA = "version_maquina"
RUTA_ARCHIVO_RECOLECTOR = "recolectorDatos.py"
RUTA_ARCHIVO_FUNCIONES = "funciones.py"