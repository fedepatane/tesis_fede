#include <X11/extensions/scrnsaver.h>
#include <stdio.h>
int main() {
  Display *dpy = XOpenDisplay(":0");
  if (dpy == NULL) {
    printf("NA");
  } else {
XScreenSaverInfo *info = XScreenSaverAllocInfo();
XScreenSaverQueryInfo(dpy, DefaultRootWindow(dpy), info);
    unsigned long idle = info->idle;
XFree(info);
XCloseDisplay(dpy);
printf("%ld", idle);
}
return 0;
}
