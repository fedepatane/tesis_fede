#!/usr/bin/python

# va a estar corriendo en cada una de las maquinas 

from funciones import *
import time
import sys

ahora = time.strftime("%X")


if estoyEnRangoDeNoche(ahora):
	sys.exit()

conexion_ssh = establecerConexionSSH()
conexion_sftp = establecerConexionSFTP(conexion_ssh)

# aca me fijo mi version actual y la q tiene el servidor , si tengo una menor ->
# me actualizo los 3 scripts y dsp me ejecuto a mi mismoooooo
# por cada maquina tengo que tener un archivo con la version actual del sistema 
version_actual = verVersionMaquina()
version_oficial = verVersionServidor(conexion_ssh)


if (version_actual < version_oficial):
	actualizarArchivos(conexion_ssh)
	actualizarVersionMaquina(version_oficial)
	sys.exit()

usuarios()
tiempoIdle()
memoria()

tiempo_para_medir_y_idle = tomarTiempoParaMedir(conexion_ssh, conexion_sftp)

tiempo_para_medir = tiempo_para_medir_y_idle[0]
tiempo_cota_idle = tiempo_para_medir_y_idle[1]

datos = definirDatosMaquina()
labo = datos[1]
maquina = datos[0]

servidor = datosDeLogs(labo, conexion_ssh, conexion_sftp)
deboLeer = servidor[0].rstrip('\n')
materia = servidor[1].rstrip('\n')

if deboLeer == "1":
	tomarDatos(tiempo_para_medir)
	moverDatos(labo, maquina, materia, conexion_ssh, conexion_sftp)

conexion_sftp.close()
conexion_ssh.close()


