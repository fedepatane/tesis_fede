// dependencia:
// apt-get install libxss-dev

// compilar con:
// gcc idle.c -lXss -lX11 -o idle

#include <X11/extensions/scrnsaver.h>
#include <stdio.h>

int main() {
  Display *dpy = XOpenDisplay(":0");

  if (dpy == NULL) {
    printf("NA\n");
  } else {
    XScreenSaverInfo *info = XScreenSaverAllocInfo();
    XScreenSaverQueryInfo(dpy, DefaultRootWindow(dpy), info);

    // milisegundos
    unsigned long idle = info->idle;

    XFree(info);
    XCloseDisplay(dpy);

    printf("%ld\n", idle);
  }

  return 0;
}
