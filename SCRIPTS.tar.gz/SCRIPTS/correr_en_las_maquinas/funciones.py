#!/usr/bin/env python

import os
import time
import sys
from configuraciones import *

from pexpect import *
from pexpect import pxssh

def tomarTiempoParaMedir(unaConexionSSH, unaConexionSFTP):
	#abrir el archivo config_general
	# si no existe q vaya a alguno generico o q no haga nada 
	unaConexionSSH.sendline("[ -f " + archivo_config_general + " ]&&echo 1 ||echo 0")	
	unaConexionSSH.prompt()  
	a =  unaConexionSSH.before
	salida = a.split("\n")[1].strip()

	if salida == "1":
		unaConexionSSH.sendline("cat " + archivo_config_general) 	#remoto
		unaConexionSSH.prompt()
		datos = unaConexionSSH.before.split("\n")[1:]

		tiempo_lectura = int(datos[0].split(" ")[1])
		tiempo_cota_idle = int(datos[1].split(" ")[1])
		return [tiempo_lectura, tiempo_cota_idle]
	else :
		sys.exit()

def verVersionMaquina():
	raiz = os.path.dirname(os.path.abspath(__file__)) + "/"
	archivo = open(raiz + RUTA_VERSION_ACTUAL_DE_LA_MAQUINA, "r")
	version = int(archivo.readline().rstrip('\n'))
	return version

def verVersionServidor(unaConexionSSH):
	unaConexionSSH.sendline("cat " + archivo_config_version)
	unaConexionSSH.prompt()             # match the prompt
	version = int(unaConexionSSH.before.split("\n")[1])    
	return version

def actualizarArchivos(unaConexionSSH):
	raiz = os.path.dirname(os.path.abspath(__file__)) + "/"
	archivo_maquina_recolector = open(raiz + RUTA_ARCHIVO_RECOLECTOR, "w")
	archivo_maquina_funciones = open(raiz + RUTA_ARCHIVO_FUNCIONES, "w")


	unaConexionSSH.sendline("cat " + archivo_update_recolector)
	unaConexionSSH.prompt()             # match the prompt
	archivo_servidor_recolector = unaConexionSSH.before.split("\n")[1:] 
	unaConexionSSH.sendline("cat " + archivo_update_funciones)
	unaConexionSSH.prompt()             # match the prompt
	archivo_servidor_funciones = unaConexionSSH.before.split("\n")[1:]

	for linea in archivo_servidor_recolector:
		archivo_maquina_recolector.write(linea + "\n")
	for linea in archivo_servidor_funciones:
		archivo_maquina_funciones.write(linea + "\n")

def actualizarVersionMaquina(unaVersion):
	raiz = os.path.dirname(os.path.abspath(__file__)) + "/"
	archivo = open(raiz + RUTA_VERSION_ACTUAL_DE_LA_MAQUINA, "w")
	unaVersion = str(unaVersion)
	archivo.write(unaVersion)

def tiempoIdle():
	raiz = os.path.dirname(os.path.abspath(__file__)) + "/"
	tmp = os.popen("who").read()
	if len(tmp) == 0:
		sys.exit()
	nombre = tmp.split("\n")[0].split(" ")[0]


	fo = open(raiz + "idlePrueba.c", "wb")
	fo.write('#include <X11/extensions/scrnsaver.h>\n')
	fo.write('#include <stdio.h>\n')
	fo.write('int main() {\n')
	fo.write('  Display *dpy = XOpenDisplay(":0");\n')
	fo.write('  if (dpy == NULL) {\n')
	fo.write('    printf("NA");\n')
	fo.write('  } else {\n')
	fo.write('XScreenSaverInfo *info = XScreenSaverAllocInfo();\n')
	fo.write('XScreenSaverQueryInfo(dpy, DefaultRootWindow(dpy), info);\n')
	fo.write('    unsigned long idle = info->idle;\n')
	fo.write('XFree(info);\n')
	fo.write('XCloseDisplay(dpy);\n')
	fo.write('printf("%ld", idle);\n')
	fo.write('}\n')
	fo.write('return 0;\n')
	fo.write('}\n')

	fo.close()

	
	os.system("gcc " + raiz + "idlePrueba.c -lXss -lX11 -o " + raiz + "idle")	
	
	os.system("su - "+nombre+" -c 'xhost +'")
	os.system( raiz + RUTA_EJECUTABLE + " > idle.time")
	
	#os.system( raiz + RUTA_EJECUTABLE + " > idle.time")
	#os.system("echo $DISPLAY > idle.time")

def usuarios():
	os.system("who > usuarios")

def memoria():
	os.system("free | awk 'NR == 2  {print $2 ,  $3 , $4}' > memoria.megas")

def estoyEnRangoDeNoche(unMomento):
	if unMomento > '23:00:00' or unMomento < '10:00:00' : 
		return True
	else : 
		return False

def establecerConexionSSH():
    s = pxssh.pxssh()
    s.login (ip_ssh, username_ssh, password_ssh)
    return s

def establecerConexionSFTP(unaConexionSSH):
	p = spawn('sftp %s@%s' %(username_ssh,ip_ssh))
	p.expect('(?i)password:')
	x = p.sendline(password_ssh)
	return p;

def definirDatosMaquina(): 
	# aca vamos a tener q armar alguna consulta a la consola para saber el nombre de la maquina 
	"""tmp = os.popen("hostname").read()
	tmp = tmp.rstrip('\n')	
	tmp = tmp.split(".")
	maquina = tmp[0].split("ws")
	maquina = maquina[1]
	labo = tmp[1].split("labo")
	labo = labo[1]
	return [maquina, labo]"""
	return ["1", "1"]

def tomarDatos(tiempo):
	#os.system("who > usuarios")
	os.system("ps aux > procesos")
	os.system("perf record -qae 'sched:sched_switch,sched:sched_stat_iowait,sched:sched_wakeup'  sleep " + str(tiempo))
	#os.system("perf script > script.data")
	return 1

def datosDeLogs(unLabo, unaConexionSSH, unaConexionSFTP):
	# abrir el archivo que le corresponde a ese labo y ver si tiene q loguear y q materia es
	directorio = servidorConfiguracion +  "LABO_" + unLabo + "/config"
	# si no existe q vaya a alguno generico o q no haga nada
	"""entrada, salida, error = unaConexionSSH.exec_command("[ -f " + directorio + " ]&&echo 1 ||echo 0") 
	salida = salida.read()
	salida = salida.rstrip('\n')"""
	salida = 1
	if salida == 1 :  
		unaConexionSSH.sendline("cat " + directorio) 	#remoto 
		unaConexionSSH.prompt()
		salida = unaConexionSSH.before
		datos = salida.split("\n")[1:]

		deboLeer = datos[0].strip()
		materiaCursando = datos[1].strip()
		return [deboLeer, materiaCursando]
	else : 
		sys.exit()

def moverDatos(unLabo, unaMaquina, unaMateria, unaConexionSSH, unaConexionSFTP):	
	#renombrar archivo de perf.data como materia_dia_hora.data
	fecha = time.strftime("%d-%m-%Y_%H:%M:%S")
	unaFecha = time.strftime("%d-%m-%Y")
	
	archivoOrigen = "perf.data"
	archivoOrigen_usuarios = "usuarios"
	archivoOrigen_procesos = "procesos"
	archivoOrigen_idle = "idle.time"
	archivoOrigen_memoria = "memoria.megas"

	archivoDestino = fecha + ".data"
	archivoDestino_usuarios = fecha + ".usuarios"
	archivoDestino_procesos = fecha + ".procesos"
	archivoDestino_idle = fecha + ".idle"
	archivoDestino_memoria = fecha + ".memoria"
	#ahora vamos a mover el archivo generado nuevo al servidor, a la carpeta que le corresponda en el servidor remoto 
	# primero vamos a crear los directorios que no existan en el remoto 
	direccion = servidorDatos + "LABO_" + unLabo + "/MAQUINA_" + unaMaquina + "/" + unaMateria + "/" + unaFecha + "/"
	archivoDestino =  direccion + archivoDestino
	archivoDestino_usuarios = direccion + archivoDestino_usuarios
	archivoDestino_procesos = direccion + archivoDestino_procesos
	archivoDestino_idle = direccion + archivoDestino_idle
	archivoDestino_memoria = direccion + archivoDestino_memoria

	if os.path.exists(archivoOrigen) and os.path.exists(archivoOrigen_usuarios)  and os.path.exists(archivoOrigen_procesos) and os.path.exists(archivoOrigen_idle):

		
		unaConexionSSH.sendline("[ -d " + servidorDatos + "LABO_" + unLabo + " ]&&echo 1 ||echo 0")
		unaConexionSSH.prompt()
		salida = unaConexionSSH.before.split("\n")[1].strip()
		if salida == "0":
			unaConexionSSH.sendline("mkdir " + servidorDatos + "LABO_" + unLabo)		
			unaConexionSSH.prompt()
		
		
		unaConexionSSH.sendline("[ -d " + servidorDatos + "LABO_" + unLabo + "/MAQUINA_" + unaMaquina + " ]&&echo 1 ||echo 0")
		unaConexionSSH.prompt()
		salida = unaConexionSSH.before.split("\n")[1].strip()
		if salida == "0": 
			unaConexionSSH.sendline("mkdir " + servidorDatos + "LABO_" + unLabo + "/MAQUINA_" + unaMaquina  )
			unaConexionSSH.prompt()
		
		
		unaConexionSSH.sendline("[ -d " + servidorDatos + "LABO_" + unLabo + "/MAQUINA_" + unaMaquina + "/" + unaMateria +  " ]&&echo 1 ||echo 0")
		unaConexionSSH.prompt()
		salida = unaConexionSSH.before.split("\n")[1].strip()
		if salida == "0": 
			unaConexionSSH.sendline("mkdir " + servidorDatos + "LABO_" + unLabo + "/MAQUINA_" + unaMaquina + "/" + unaMateria)
			unaConexionSSH.prompt()
		
		
		unaConexionSSH.sendline("[ -d " + servidorDatos + "LABO_" + unLabo + "/MAQUINA_" + unaMaquina + "/" + unaMateria + "/" + unaFecha + " ]&&echo 1 ||echo 0")
		unaConexionSSH.prompt()
		salida = unaConexionSSH.before.split("\n")[1].strip()
		if salida == "0": 
			unaConexionSSH.sendline("mkdir " + servidorDatos + "LABO_" + unLabo + "/MAQUINA_" + unaMaquina + "/" + unaMateria + "/" + unaFecha)
			unaConexionSSH.prompt()
		

		"""unaConexionSFTP.put(archivoOrigen , archivoDestino)
		unaConexionSFTP.put(archivoOrigen_usuarios, archivoDestino_usuarios)
		unaConexionSFTP.put(archivoOrigen_procesos, archivoDestino_procesos)
		unaConexionSFTP.put(archivoOrigen_idle, archivoDestino_idle)"""


		x = unaConexionSFTP.expect('sftp>')
		x = unaConexionSFTP.sendline("put " + archivoOrigen_idle + " " + archivoDestino_idle)
		x = unaConexionSFTP.expect('sftp>')
		x = unaConexionSFTP.sendline("put " + archivoOrigen + " " + archivoDestino)
		x = unaConexionSFTP.expect('sftp>')
		x = unaConexionSFTP.sendline("put " +  archivoOrigen_usuarios + " " + archivoDestino_usuarios)
		x = unaConexionSFTP.expect('sftp>')
		x = unaConexionSFTP.sendline("put " +  archivoOrigen_procesos + " " + archivoDestino_procesos)
		x = unaConexionSFTP.expect('sftp>')
		x = unaConexionSFTP.sendline("put " +  archivoOrigen_memoria + " " + archivoDestino_memoria)
		x = unaConexionSFTP.expect('sftp>')


	return 1



